// #include <QGuiApplication>
// #include <QQmlApplicationEngine>
// #include <QtWebEngineQuick>

// int main(int argc, char *argv[])
// {
//     QGuiApplication app(argc, argv);

//     // Register the Qt WebEngine module
//     QtWebEngineQuick::initialize();

//     QQmlApplicationEngine engine;

//     // Load the QML file
//     engine.load(QUrl(QStringLiteral("qrc:/main.qml")));

//     // Check for errors loading QML
//     if (engine.rootObjects().isEmpty())
//         return -1;

//     return app.exec();
// }

#include <QApplication>
#include <QWebEngineView>
#include <QWebChannel>
#include "fileSaver.h"

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);

    QWebEngineView view;
    view.setUrl(QUrl("qrc:/index.html")); // Loading the HTML file from resources

    // Create an instance of FileSaver
    FileSaver fileSaver;

    // Set up the QWebChannel to communicate between JS and C++
    QWebChannel *channel = new QWebChannel(&view);
    view.page()->setWebChannel(channel);
    channel->registerObject(QStringLiteral("fileSaver"), &fileSaver);

    view.show();
    return app.exec();
}
